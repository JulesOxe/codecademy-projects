package myproject

class BootStrap {

    def init = { servletContext ->
    }
    def destroy = {
    }
}
